
@extends('AdminLTE')
@section('content')
<style>
    .panel-heading{
        padding: 25px 15px;
    }
    .summary {
        text-align: center;
        background-color: #ffc261;
    }
    .w3-table-all td, th {
        text-align: center;
    }
</style>
<div class="container" style="width:95%">


    @if(count($errors) > 0)
        <div class="alert alert-danger">
            Upload Validation Error<br><br>
            <ul>
                @foreach($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif


    
    <div class="panel panel-default">
        <div class="panel-heading">
            <h3 class="panel-title">Report preview </h3>
            <table style="width: 100%;background-color: #ffd187;    border-radius: 11px;direction: rtl;
    margin-top: 15px;
}" id="summary">
                <tr style="background-color: #ebbd73;text-align: center;">
                    <th>تفاصيل مسار الملف </th>
                    <th>مجموع المبالغ</th>
                    <th>مجموع الديون</th>
                    <th>عدد المناديب</th>
                    <th>عدد المناديب الجدد</th>
                </tr>
                <tr style="text-align: center;">
                    <td>{{$extra['tem']->path}}</td>
                    <td>{{$extra['grandTotal']}}</td>
                    <td> - </td>
                    <td> - </td>
                    <td> - </td>
                </tr>
                <tr>
                    <td colspan="5"><button class="btn btn-success"style="float:left;margin: 10px;" id="confirmBtn" onclick="confirmInvoce()">تأكيد وتصدير الى Journal</button></td>
                </tr>
            </table>
        </div>

        <div class="panel-body">
            <div class="table-responsive">
                <table class="table table-bordered table-striped">
                    <tr>
                    <th>Hub Code</th>
                    <th>Emp ID</th>
                    <th>Driver name</th>
                    <th>Registration status</th>
                    <th class="table-cell-package">amount</th>
                    </tr>
                    <?php $i=0?>
                    @foreach($payload as $item)
                        <tr>
                            <th>{{$item[0]}}</th>
                            <th>{{$item[1]}}</th>
                            <th width="10%" style="text-align: center;">{{$item[2]}} 
                            </th>
                             <th>
                             @if($item[4] == 'notRegistered')
                                <span class="btn" style="background-color:green;color:white;  border-radius: 50%;max-width: 116px;  font-size: 12px;">New </span>
                             @else
                                <span class="btn" style="background-color:green;color:white;  border-radius: 50%;max-width: 116px;  font-size: 12px;">Registered </span>
                             @endif
                             </th>
                             <th>{{$item[3]}}</th>
                             
                        </tr>
                    @endforeach
                    <tr style="background-color: #f29a0f;">
                            <th colspan="2"> Recoreds : {{$extra['qty']}} </th>
                            
                            <th></th>
                             <th></th>
                             <th colspan="2" style="text-align: center;">{{$extra['grandTotal']}}</th>
                        </tr>
                </table>
            </div>
        </div>
    </div>




<!-- extra -->













    </div>
</body>
</html>
<script>
    $(function () {
        $('#pakage_date').datepicker({
            format: 'dd/mm/yyyy',
            autoclose: true,
            autoHide: true,
            zIndex: 9999,
        });
    });

function confirmInvoce(){
    //confirmBtn
    
    const button = document.getElementById('confirmBtn');
    button.disabled = true;
    let url = '{{url('import_excel/i-mile/confirme')}}';
    var postData = {
        file_id:"{{$extra['file_id']}}",
        journal_date:"{{$extra['tem']->journal_date}}",
        journal_period:"{{$extra['tem']->journal_period}}",
        _token: "{{ csrf_token() }}",
    };
    
    $.ajax({
                url: url,
                type: "POST",
                cache: false,
                data: postData,
                success: function (data) {
                    // console.log(data);
                    if(data.status == true){
                        alert('Exporting to journal succeed');
                        window.location.replace('/import_excel/General-invoices');
                        // return redirect()->with('success','has done')
                    }else{
                        alert(data.error);
                        window.location.replace('/import_excel/General-invoices');
                    }
                },
                error: function (jqXHR, status, error) {
                   
                    alert(status + ": " + error);
                }
            });

    
   
    }
</script>
@endsection
