<!-- <link href="http://localhost/mashaueer_noon/resources/layout/styles/layout.css " rel="stylesheet" type="text/css" media="all">
-->
<!DOCTYPE html>
<html lang="en">
<html>
<head>
    <title>Admin - Almashwar</title>
    <!-- <meta charset="utf-8"> -->
    <META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=iso-8859-6">
        <META HTTP-EQUIV="Content-language" CONTENT="ar">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">

            <!-- <link href="http://localhost/mashaueer_noon/resources/ " rel="stylesheet" type="text/css" media="all"> -->
            <!-- Tell the browser to be responsive to screen width -->
            <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
            <!-- Bootstrap 3.3.7 -->
            <link rel="stylesheet" href="{{asset("/AdminLTE/css/bootstrap.min.css")}}">

            <!-- Font Awesome -->
            <link rel="stylesheet" href="{{asset("/AdminLTE/font-awesome/font-awesome.min.css")}}">
            <!-- Ionicons -->
            <link rel="stylesheet" href="{{asset("/AdminLTE/css/ionicons.min.css")}}">

            <!-- daterange picker -->
            <link rel="stylesheet" href="{{asset("/AdminLTE/bootstrap-daterangepicker/daterangepicker.css")}}">
            <!-- bootstrap datepicker -->
            <link rel="stylesheet"
                  href="{{asset("/AdminLTE/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css")}}">
            <!-- Theme style -->
            <!-- iCheck for checkboxes and radio inputs -->
            <link rel="stylesheet" href="{{asset("/AdminLTE/plugins/iCheck/all.css")}}">
            <link rel="stylesheet" href="{{asset("/AdminLTE/css/AdminLTE.css")}}">
            <!-- AdminLTE Skins. Choose a skin from the css/skins
            folder instead of downloading all of them to reduce the load. -->
            <link rel="stylesheet" href="{{asset("/AdminLTE/css/_all-skins.min.css")}}">
            <link rel="stylesheet" href="{{asset("/AdminLTE/css/dataTables.bootstrap.min.css")}}">
            <!--<link  href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css" rel="stylesheet">-->
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
            <link rel="stylesheet" href="https://www.w3schools.com/lib/w3.css">
            <link rel="stylesheet"
                  href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
            <link rel="stylesheet" href="{{asset("/AdminLTE/css/AdminLTE.css")}}">
            <link rel="stylesheet" href="{{asset("/AdminLTE/css/customize.css")}}">
            </head>

            <style>
                .show_table th {
                    padding-left: 20px !important;
                    white-space: nowrap;
                    border: none !important;
                    margin: 0 !important;
                }

                .show_table td {
                    padding: 0.0rem 0.0rem !important;
                    border: none !important;
                    vertical-align: middle !important;
                }
            </style>
            @include('pages.messages')
            <div style="float:left;margin-top: 5px;margin-left: 20px;width:100%;"><h2
                    style="width:100%;font-size: 14px;font-weight: bold;">Loans</h2>
            </div>

            <form method="POST" action="{{ route('Loans.update',$Loans->id)}}">
                {{method_field("PATCH")}}
                @csrf

                <table>
                    <tr>
                        <td style="vertical-align: top !important;">
                            <table class="table m-0 show_table" style="width:10px!important;">
                                <tr>
                                    <TH>Driver <font color="red">*</font></TH>
                                    <td style="white-space: nowrap;">
                                        <input name="driverId" id="driverId" type="hidden" value="{{$Loans->driverId}}">
                                        <table style="padding: 0px 0px; !important;">
                                            <tr>
                                                <td>
                                                    <input class="form-control" name="driverId_input"
                                                           id="driverId_input" style="width:200px" type="text"
                                                           value="{{$Loans->fullName}}" required data-readonly>
                                                </td>
                                                <td>
                                                    <button onclick="driver_window();" type="button"
                                                            class="btn btn-primary btn-sm">Select
                                                    </button>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                                <Tr>
                                    <TH colspan=2 id="balance">
                                        <table>
                                            <tr>
                                                <TH>Perivious Balance:</TH>
                                                <td><font color=red>{{$Loans->per_priod}}</font> ({{$Loans->per_range}})
                                                <td>
                                            </tr>
                                            <tr>
                                                <TH style='text-align: right;'>Current Balance:</TH>
                                                <td><font color=red>{{$Loans->cur_priod}}</font> ({{$Loans->cur_range}})
                                                <td>
                                            </tr>
                                        </table>

                                    </TH>
                                </tr>
                                <tr>
                                    <TH>journal Date <font color="red">*</font></TH>

                                    <td>
                                        <select name="journal_period" id="journal_period"
                                                class="form-control" style="width:300px;" required>
                                            <option value=""> Select ...</option>
                                            <option value="1"
                                                    @if ($Loans->journal_period==$Loans->per_range){{"  selected " }}:null @endif>
                                                Previous ({{$Loans->per_range}})
                                            </option>
                                            <option value="2"
                                                    @if ($Loans->journal_period==$Loans->cur_range){{"  selected " }}:null @endif>
                                                Current ({{$Loans->cur_range}})
                                            </option>
                                        </select>
                                    <!--<div class="input-group date">
                  <div class="input-group-addon">
                    <i class="fa fa-calendar"></i>
                  </div>
                  <input type="text" class="form-control pull-right" name="journal_date" placeholder="dd/mm/yyyy" id="journal_date" value="{{$Loans->journal_date}}" required>
                </div>-->
                                    </td>
                                </tr>
                                <tr>
                                    <TH>Amount <font color="red">*</font></TH>
                                    <td><input type="text" class="form-control" name="amount" value="{{$Loans->amount}}"
                                               required></td>
                                </tr>
                                <tr>
                                    <TH>Note</TH>
                                    <td><textarea name="note" class="form-control" rows=5>{{$Loans->note}}</textarea>
                                    </td>
                                </tr>
                                </td>
                                </tr>
                                <tr>
                                    <TH>Status<font color="red">*</font></TH>
                                    <td>
                                        <select id="status_id" name="status_id" class="form-control" required>
                                            <option value=""></option>
                                            @foreach($lkp_loan_status as $lkp_loan_statuss)
                                                <option value="{{$lkp_loan_statuss->id}}"
                                                        @if ($Loans->status_id==$lkp_loan_statuss->id){{"  selected " }}:null @endif>{{$lkp_loan_statuss->loan_status}}</option>
                                            @endforeach
                                        </select>
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                </table>
                <div class="w3-row">
                    <button class="w3-btn-block w3-indigo w3-section w3-padding" type="submit">Update</button>
                </div>
            </form>
            <div class="w3-container w3-border-top w3-padding-16 w3-light-grey">
                <button onclick="window.close()" type="button" class="w3-btn w3-red">Close</button>
            </div>
            <script>
                function driver_window() {
                    myWindow1 = window.open("{{URL("/DriverWindow")}}", "",
                        "height=650,width=1000,scrollbars=yes,top=1,left=1,status,resizable");
                }
            </script>
