<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Admin - Almashwar</title>
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.7 -->
    <link rel="stylesheet" href="{{asset("/AdminLTE/css/bootstrap.min.css")}}">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="{{asset("/AdminLTE/font-awesome/font-awesome.min.css")}}">
    <!-- Ionicons -->
    <link rel="stylesheet" href="{{asset("/AdminLTE/css/ionicons.min.css")}}">
    <!-- daterange picker -->
    <link rel="stylesheet" href="{{asset("/AdminLTE/bootstrap-daterangepicker/daterangepicker.css")}}">
    <!-- bootstrap datepicker -->
    <link rel="stylesheet"
          href="{{asset("/AdminLTE/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css")}}">
    <!-- Theme style -->
    <!-- iCheck for checkboxes and radio inputs -->
    <link rel="stylesheet" href="{{asset("/AdminLTE/plugins/iCheck/all.css")}}">
    <!-- AdminLTE Skins. Choose a skin from the css/skins
    folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="{{asset("/AdminLTE/css/_all-skins.min.css")}}">
    <link rel="stylesheet" href="{{asset("/AdminLTE/css/dataTables.bootstrap.css")}}">
    <!--<link href="https://datatables.yajrabox.com/css/datatables.bootstrap.css" rel="stylesheet">-->
    <!--<link  href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css" rel="stylesheet">-->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
    <link rel="stylesheet" href="{{asset("/AdminLTE/css/w3.css")}}">
    <link rel="stylesheet"
          href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
    <link rel="stylesheet" href="{{asset("/AdminLTE/css/AdminLTE.css")}}">
    <link rel="stylesheet" href="{{asset("/AdminLTE/css/customize.css")}}">
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">
    <header class="main-header">
        <!-- Logo -->
        <a href="{{URL("/AdminLTE/Home")}}" class="logo">
            <!-- mini logo for sidebar mini 50x50 pixels -->
            <span class="logo-mini"><b>M</b>AH</span>
            <!-- logo for regular state and mobile devices -->
            <span class="logo-lg"><b>MAL</b>CO.</span>
        </a>
        <!-- Header Navbar: style can be found in header.less -->
        <nav class="navbar navbar-static-top">
            <!-- Sidebar toggle button-->
            <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
                <span class="sr-only">Toggle navigation</span>
            </a>
        </nav>
    </header>
    <!-- Left side column. contains the logo and sidebar -->
    <aside class="main-sidebar">
        <!-- sidebar: style can be found in sidebar.less -->
        <section class="sidebar">
            <!-- Sidebar user panel -->
            <div class="user-panel">
                <div class="pull-left image">
                    <img src="{{asset("/AdminLTE/img/user2-160x160.jpg")}}" class="img-circle" alt="User Image">
                </div>
                @if (empty(Auth::user()))
                    <div class="pull-left info">
                        <p><a href="{{ route('login') }}" class="d-block">Login</a></p>
                    </div>
                @else
                    <div class="pull-left info">
                        <p>{{ Auth::user()->name }}</p>
                        <i class="fa fa-circle text-success"></i> Online
                        <a href="{{ route('logout') }}"
                           onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();"><img
                                src="{{asset("/AdminLTE/img/logout.jpg")}}" style="height:12px;width:60px"></a>
                        <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                            {{ csrf_field() }}
                        </form>
                    </div>
                @endif
            </div>
<br>

        @if (!empty(Auth::user()))
            <!-- sidebar menu: : style can be found in sidebar.less -->
            <ul class="sidebar-menu" data-widget="tree">
                <li class="{{ request()->is('home') ? 'active' : '' }}"><a href="{{URL("/home")}}"><i
                            class="fa fa-dashboard"></i> <span>Dashboard</span></a></li>

                <li class="header">Operations</li>

                <li class="{{ request()->is('Users') ? 'active' : '' }}"><a href="{{URL("/Users")}}"><i
                            class="fa fa-user"></i> <span>Users</span></a></li>
                <li class="{{ request()->is('Warehouses') ? 'active' : '' }}"><a href="{{URL("/Warehouses")}}"><i
                            class="fa fa-home"></i> <span>Warehouses</span></a></li>
                <li class="{{ request()->is('Drivers') ? 'active' : '' }}"><a href="{{URL("/Drivers")}}"><i
                            class="fa fa-automobile"></i> <span>Drivers</span></a></li>
                <li class="treeview {{(request()->is('import_excel*')||request()->is('import_excel_zajil*')) ? 'active' : '' }}">
                    <a href="#">
                        <i class="fa fa-edit"></i> <span>Import From Excel</span>
                        <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
                    </a>
                    <ul class="treeview-menu">
                        <li class="{{ request()->is('import_excel') ? 'active' : '' }}"><a
                                href="{{URL("/import_excel")}}"><i class="fa fa-circle-o"></i> <span>Noon</span></a>
                        </li>
                        <li class="{{ request()->is('import_excel_zajil') ? 'active' : '' }}"><a
                                href="{{URL("/import_excel_zajil")}}"><i class="fa fa-circle-o"></i>
                                <span>Zajil</span></a></li>
                    </ul>
                </li>
                <li class="{{ request()->is('Packages') ? 'active' : '' }}"><a href="{{URL("/Packages")}}"><i
                            class="fa fa-briefcase"></i> <span>Packages</span></a></li>

                <li class="header">Tracking</li>



                <li class="{{ request()->is('GoogleMap') ? 'active' : '' }}"><a href="{{URL("/GoogleMap")}}"><i
                            class="fa fa-map"></i> <span>Google Map</span></a></li>
                <li class="{{ request()->is('GoogleMapTrack') ? 'active' : '' }}"><a
                        href="{{URL("/GoogleMapTrack")}}"><i class="fa fa-map-marker"></i>
                        <span>Google Map Track</span></a>
                </li>
                <li class="{{ request()->is('GoogleMapAttend') ? 'active' : '' }}"><a
                        href="{{URL("/GoogleMapAttend")}}"><i class="fa fa-map-signs"></i>
                        <span>Supervisors Attendance</span></a></li>
                <li class="{{ request()->is('GoogleMapUser') ? 'active' : '' }}"><a href="{{URL("/GoogleMapUser")}}"><i
                            class="fa fa-map-pin"></i>
                        <span>Supervisor Attendance</span></a></li>



                <li class="header">Accounts</li>



                <li class="{{ request()->is('Loans') ? 'active' : '' }}"><a href="{{URL("/Loans")}}"><i
                            class="fa fa-money"></i> <span>Loans</span></a></li>
                <li class="{{ request()->is('Journal') ? 'active' : '' }}"><a href="{{URL("/Journal")}}"><i
                            class="fa fa-book"></i> <span>Journal</span></a></li>
                <li class="{{ request()->is('Salary') ? 'active' : '' }}"><a href="{{URL("/Salary")}}"><i
                            class="fa fa-money"></i> <span>Salary</span></a></li>
            <!--<li><a href="{{URL("/PostPackages")}}"><i class="fa fa-automobile"></i> <span>PostPackages</span></a></li>-->
                <li class="{{ request()->is('CreditNotes') ? 'active' : '' }}"><a href="{{URL("/CreditNotes")}}"><i
                            class="fa fa-bookmark"></i> <span>CreditNotes</span></a></li>
            <!--<li><a href="{{URL("/Gaps")}}"><i class="fa fa-automobile"></i> <span>Gaps++</span></a></li>-->
                <li class="{{ request()->is('Settlements') ? 'active' : '' }}"><a href="{{URL("/Settlements")}}"><i
                            class="fa fa-money"></i> <span>Settlements</span></a></li>
                <li class="{{ request()->is('Attendance') ? 'active' : '' }}"><a href="{{URL("/Attendance")}}"><i
                            class="fa fa-address-card"></i> <span>Attendance</span></a></li>

                <li class="{{ request()->is('Clearance') ? 'active' : '' }}"><a href="{{URL("/Clearance")}}"><i
                            class="fa fa-clipboard"></i>
                        <span>Clearance</span></a></li>
                <li class="{{ request()->is('driverInvoices') ? 'active' : '' }}"><a href="{{URL("/driverInvoices")}}"><i
                            class="fa fa-file-excel-o"></i>
                        <span>Diver Invoices By Supervisors</span></a></li>
                <li class="{{ request()->is('ExportInvoice') ? 'active' : '' }}"><a href="{{URL("/ExportInvoice")}}"><i
                            class="fa fa-file-excel-o"></i>
                        <span>Export Invoice</span></a></li>
                <li class="treeview {{(request()->is('Report_Loan*')||request()->is('Report_Salary*')) ? 'active' : '' }}">
                    <a href="#">
                        <i class="fa fa-edit"></i> <span>Reports</span>
                        <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
                 </span>
                    </a>
                    <ul class="treeview-menu">
                        <li class="{{ request()->is('Report_Loan') ? 'active' : '' }}"><a
                                href="{{URL("/Report_Loan")}}"><i class="fa fa-circle-o"></i>
                                <span>Loan Report</span></a></li>
                        <li class="{{ request()->is('Report_Salary') ? 'active' : '' }}"><a
                                href="{{URL("/Report_Salary")}}"><i class="fa fa-circle-o"></i>
                                <span>Salary Report</span></a></li>
                    </ul>
                </li>


                <li class="treeview {{(request()->is('Packages_Backup*')||request()->is('Packages_Report*')) ? 'active' : '' }}">
                    <a href="#">
                        <i class="fa fa-briefcase"></i> <span>Packages Backup</span>
                        <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
                       </span>
                    </a>
                    <ul class="treeview-menu">
                        <li class="{{ request()->is('Packages_Backup') ? 'active' : '' }}"><a
                                href="{{URL("/Packages_Backup")}}"><i class="fa fa-circle-o"></i>
                                <span>Packages</span></a></li>
                        <li class="{{ request()->is('Packages_Report') ? 'active' : '' }}"><a
                                href="{{URL("/Packages_Report")}}"><i class="fa fa-circle-o"></i>
                                <span>Report</span></a></li>
                    </ul>
                </li>

                <li class="header">Administration</li>


                <li class="{{ request()->is('versionControl') ? 'active' : '' }}"><a href="{{URL("/versionControl")}}"><i
                            class="fa fa-mobile"></i> <span>Version Control</span></a></li>
            </ul>
            @endif
        </section>
        <!-- /.sidebar -->
    </aside>



    <div class="content-wrapper" style="padding:5px">
        <!-- Content Header (Page header) -->



    @include('pages.loader')
    @include('pages.messages')
    @yield('content')
    <!-- /.content -->
    </div>
    <!---Foter-------------------------------------------------------------------------------------------------------->
    <footer class="main-footer">
        <div class="pull-right hidden-xs">
            <b>Meshwar Aseemah</b>
        </div>
        <strong>Copyright &copy; 2014-2020 Almsaeed Studio.</strong> All rights
        reserved.
    </footer>

    <!-- /.control-sidebar -->
    <!-- Add the sidebar's background. This div must be placed
         immediately after the control sidebar -->
    <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->
<!-- jQuery 3 -->
<script src="{{asset("/AdminLTE/js/jquery.min.js")}}"></script>
<script src="{{asset("/AdminLTE/js/select2.full.min.js")}}"></script>
<!-- Bootstrap 3.3.7 -->
<script src="{{asset("/AdminLTE/js/bootstrap.min.js")}}"></script>
<!-- date-range-picker -->
<script src="{{asset("/AdminLTE/moment/min/moment.min.js")}}"></script>
<script src="{{asset("/AdminLTE/bootstrap-daterangepicker/daterangepicker.js")}}"></script>
<!-- bootstrap datepicker -->
<script src="{{asset("/AdminLTE/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js")}}"></script>
<script src="{{asset("/AdminLTE/js/jquery.dataTables.min.js")}}"></script>
<script src="{{asset("/AdminLTE/js/dataTables.bootstrap.min.js")}}"></script>
<!--<script src="https://datatables.yajrabox.com/js/jquery.dataTables.min.js"></script>
<script src="https://datatables.yajrabox.com/js/datatables.bootstrap.js"></script>-->
<script src="{{asset("/AdminLTE/js/dataTables.buttons.min.js")}}"></script>
<script src="{{asset("/AdminLTE/js/buttons.html5.js")}}"></script>
<script src="{{asset("/AdminLTE/js/jszip.min.js")}}"></script>
<!-- FastClick -->
<script src="{{asset("/AdminLTE/js/fastclick.js")}}"></script>
<!-- iCheck 1.0.1 -->
<script src="{{asset("/AdminLTE/plugins/iCheck/icheck.min.js")}}"></script>
<!-- AdminLTE App -->
<script src="{{asset("/AdminLTE/js/adminlte.min.js")}}"></script>
<script>
    $(document).ready(function () {
        setTimeout("preventBack()", 0);
        window.onunload = function () {
            null
        };
    });
    function preventBack() {
        window.history.forward();
    }
</script>
<!--<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.2/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.flash.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>-->

